/** Automatically generated file. DO NOT MODIFY */
package kielian.fft_to_voltage_w_charts;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}